rows = 8
cols = 8
class Piece:
    def __init__(self, row, column, color):
        self.row = row
        self.column = column
        self.color = color


class Board:
    def __init__(self, board):
        self.board = board
    
    def get_piece(self, row, col):
        return self.board[row][col]

bo= [[1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [Piece(3, 0, 'R'), 0, Piece(3, 2, 'R'), Piece(3, 3, 'R'), 0, 0, 0, 0],
        [0, Piece(4, 1, 'W'), 0, Piece(4, 3, 'W'), 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, Piece(6, 1, 'W'), 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0]]
boo = Board(bo)

def white_moves(piece):
    values = set()
    jumped = []
    row = piece.row
    left, right = piece.column, piece.column
    l_visited, r_visited = [], []
    for i in range(0, 3):
        if i==1:
            if left-i>-1 and row+i<rows: 
                if boo.board[row+i][left-i] == 0:
                    values.add((row+i, left-i))
                else:
                    piece = boo.get_piece(row+i, left-i)
                    if piece.color == 'R':
                        continue
                    else:
                        l_visited.append(1)
                        print(row+i, left-i)
            if right+i<cols and row+i<rows:
                if boo.board[row+i][right+i] == 0:
                    print( boo.board[row+i][right+1] )
                    values.add((row+i, right+i))
                    
                    
                else:
                    piece = boo.get_piece(row+i, right+i)
                    if piece.color == 'R':
                        continue
                    else:
                        r_visited.append(1)
        else:
            if left-i>-1 and row+i<rows:
                if boo.board[row+i][left-i] ==0 and l_visited:
                    values.add((row+i, left-i))
                    jumped.append((row+i,left-i))
                else:
                    continue
            if right+i<cols and row+i<rows:
                if boo.board[row+i][right+i] == 0 and r_visited:
                    values.add((row+i, right+i))
                    jumped.append((row+i,right+i))
                else:
                    continue
    old_values = values
    for e in jumped:
        x, y = e
        old_val, val, jum = red_moves(Piece(x, y, 'R'))
        for i in range(len(jum)):
            print(jum[i])
            jumped.append(jum[i])
        values = val.union(values)
        
    return (old_values, values, jumped)
old_val, val, jum = red_moves(Piece(3, 0, 'R'))
def give_final_output(x, y):
    return x.union(y)

print(f"white-------{give_final_output(old_val, jum)}")

#####################################################################################################################################

def red_moves(piece):
    values = set()
    jumped = []
    row = piece.row
    left, right = piece.column, piece.column
    l_visited, r_visited = [], []
    for i in range(0, 3):
        if i==1:
            if left-i>-1 and row-i>0: 
                if boo.board[row-i][left-i] == 0:
                    values.add((row-i, left-i))
                else:
                    piece = boo.get_piece(row-i, left-i)
                    if piece.color == 'W':
                        continue
                    else:
                        l_visited.append(1)
                        print(row-i, left-i)
            if right+i<cols and row-i>0:
                if boo.board[row-i][right+i] == 0:
                    print( boo.board[row-i][right+1] )
                    values.add((row-i, right+i))
                    
                    
                else:
                    piece = boo.get_piece(row-i, right+i)
                    if piece.color == 'W':
                        continue
                    else:
                        r_visited.append(1)
        else:
            if left-i>-1 and row-i>0:
                if boo.board[row-i][left-i] ==0 and l_visited:
                    values.add((row-i, left-i))
                    jumped.append((row-i,left-i))
                else:
                    continue
            if right+i<cols and row-i>0:
                if boo.board[row-i][right+i] == 0 and r_visited:
                    values.add((row-i, right+i))
                    jumped.append((row-i,right+i))
                else:
                    continue
    old_values = values
    for e in jumped:
        x, y = e
        old_val, val, jum = white_moves(Piece(x, y, 'W'))
        for i in range(len(jum)):
            print(jum[i])
            jumped.append(jum[i])
        values = val.union(values)
        
    return (old_values, values, jumped)
old_val_, val_, jum_ = white_moves(Piece(4 , 1, 'W'))

print(f"red-------{give_final_output(old_val_, jum_)}")

