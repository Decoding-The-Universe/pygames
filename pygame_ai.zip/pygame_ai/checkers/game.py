import pygame
from .constants import RED, WHITE, BLUE, SQUARE_SIZE, COLS, ROWS
from .board import Board
from .pieces import Piece
class Game:
    def __init__(self, win):
        self._init()
        self.win = win

    def update(self, pos):
        self.board.draw(self.win)
        row, col = pos[0]
        pygame.display.update() 
        self.piece = self.board.get_piece(row, col)
        if self.piece != 0:
            old_values, values, jumped = self.red_moves(self.piece)
            moves = self.give_final_output(old_values, jumped)
            self.valid_moves[self.piece] = moves
            self.selected = self.piece
            self.draw_valid_moves(moves)
        else:
            if self.selected != None:
                if (row, col) in self.valid_moves[self.selected]:
                    self.board.move(self.selected, row, col)
                    self.selected.draw(self.win)
                    self.valid_moves.pop(self.selected)
                    zero_piece = self.board.get_piece(self.selected.row, self.selected.col)
                    zero_piece.draw(self.win)
                    self.selected = None

            else:
                self.valid_moves = {}

        pygame.display.update()  
    
    def reset(self):
        self._init()

    def _init(self):
        self.selected = None
        self.turn = RED
        self.board = Board()
    
        self.valid_moves = {}


    def draw_valid_moves(self, moves):
        for move in moves:
            row, col = move
            pygame.draw.circle(self.win, BLUE, (col*SQUARE_SIZE + SQUARE_SIZE//2, row*SQUARE_SIZE + SQUARE_SIZE//2), 15)



    def red_moves(self, piece):
        values = set()
        jumped = []
        row = piece.row
        left, right = piece.col, piece.col
        l_visited, r_visited = [], []
        for i in range(0, 3):
            if i==1:
                if left-i>-1 and row-i>0: 
                    if self.board.board[row-i][left-i] == 0:
                        values.add((row-i, left-i))
                    else:
                        piece = self.board.get_piece(row-i, left-i)
                        if piece.color == RED:
                            continue
                        else:
                            l_visited.append(1)
                if right+i<COLS and row-i>0:
                    if self.board.board[row-i][right+i] == 0:
                        values.add((row-i, right+i))
                        
                        
                    else:
                        piece = self.board.get_piece(row-i, right+i)
                        if piece.color == RED:
                            continue
                        else:
                            r_visited.append(1)
            else:
                if left-i>-1 and row-i>0:
                    if self.board.board[row-i][left-i] ==0 and l_visited:
                        values.add((row-i, left-i))
                        jumped.append((row-i,left-i))
                    else:
                        continue
                if right+i<COLS and row-i>0:
                    if self.board.board[row-i][right+i] == 0 and r_visited:
                        values.add((row-i, right+i))
                        jumped.append((row-i,right+i))
                    else:
                        continue
        old_values = values
        for e in jumped:
            x, y = e
            old_val, val, jum = self.red_moves(Piece(x, y, RED))
            for i in range(len(jum)):
                print(jum[i])
                jumped.append(jum[i])
            values = val.union(values)
            
        return (old_values, values, jumped)

    def give_final_output(self, x, y):
        return x.union(y)
'''
    def select(self, row, col):
        if self.selected:
            result = self._move(row, col) 
            if not result:
                self.selected = None
                self.select(row, col)
        else:
            piece = self.board.get_piece(row, col)
            if piece !=0 and piece.color == self.turn: #think mistaken here.......
                self.selected = piece
                self.valid_moves = self.board.get_valid_moves(piece)
                return True
        return False #also check here


    def _move(self, row, col):
        piece = self.board.get_piece(row, col)
        if self.selected and piece == 0 and (row, col) in self.valid_moves:
            self.board.move(self.seleceted, row, col)
            self.change_turn()
        else:
            return False
        return True
    def change_turn(self):
        if self.turn == RED:
            self.turn == WHITE
        else:
            self.turn == RED

    def get_valid_moves(self, piece):
        moves = {}
        left = piece.col-1
        right = piece.col+1
        row = piece.row
        if piece.color ==RED or piece.king:
            moves.update(self._traverse_left(row-1, max(row-3, -1), RED, left))
            moves.update(self._traverse_right(row-1, max(row-3, -1), -1, RED, right))
        if piece.color == WHITE or piece.king:
            moves.update(self._traverse_left(row+1 , min(ROWS, row+3), 1, RED, left))
            moves.update(self._traverse_left(row+1, row+3, 1, RED, right))


    def _traverse_left(self, start, stop, step, color, left, skipped=[]):
        moves = {}
        last =[]
        for r in range(start, stop, step):
            if left<0:
                break
            current = self.board.get_piece(r, left)
            if current ==0:
                if skipped and not last:
                    break
                elif skip_only:
                    pass
                else:
                    moves[(r, left)] = last
                if last:
                    
            left-=1
    def _traverse_right(self, start, stop, step, color, right, skipped=[]):
        pass
'''